<?php  $api_url = "https://API_URL_HERE"; $SAVE_TO_TXT = TRUE; ?>
